import os, json, time, threading, datetime, requests, gc
import google.generativeai as genai

# --- CONFIGURATION ---
STATE_PATH = 'Vultix_Master_State.json'

class VultixSovereign:
    def __init__(self):
        self.fuel = {
            'GEMINI_API_KEY': os.environ.get('GEMINI_API_KEY'),
            'TELEGRAM_BOT_TOKEN': os.environ.get('TELEGRAM_BOT_TOKEN'),
            'OMAR_CHAT_ID': os.environ.get('OMAR_CHAT_ID')
        }
        self.state = self.load_state()
        self.init_brain()

    def load_state(self):
        if os.path.exists(STATE_PATH):
            with open(STATE_PATH, 'r') as f: return json.load(f)
        return {'status': 'DEPLOYED', 'cycle': 0}

    def sync_state(self):
        self.state['last_sync'] = datetime.datetime.now().isoformat()
        with open(STATE_PATH, 'w') as f: json.dump(self.state, f, indent=4)

    def init_brain(self):
        if self.fuel['GEMINI_API_KEY']:
            genai.configure(api_key=self.fuel['GEMINI_API_KEY'])
            self.brain = genai.GenerativeModel('gemini-1.5-flash-latest')

    def send_signal(self, text):
        url = f"https://api.telegram.org/bot{self.fuel['TELEGRAM_BOT_TOKEN']}/sendMessage"
        requests.post(url, json={'chat_id': self.fuel['OMAR_CHAT_ID'], 'text': text, 'parse_mode': 'Markdown'})

    def run_eternal_loop(self):
        self.send_signal("🚀 **VULTIX ONLINE ON CLOUD**\nSystem has successfully migrated and is now independent.")
        while True:
            try:
                # Production Logic
                self.state['cycle'] += 1
                self.sync_state()
                time.sleep(3600) # Hourly Heartbeat
            except Exception as e:
                self.send_signal(f"⚠️ Error in loop: {e}")
                time.sleep(60)

if __name__ == '__main__':
    vultix = VultixSovereign()
    vultix.run_eternal_loop()
